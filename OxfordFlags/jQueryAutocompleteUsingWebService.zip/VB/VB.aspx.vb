﻿
Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Submit(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim customerName As String = Request.Form(txtSearch.UniqueID)
        Dim customerId As String = Request.Form(hfCustomerId.UniqueID)
    End Sub
End Class
